Launch - in "NewLangHelper.Client" dir, execute:

Windows: python -m http.server			(requires Anaconda)
Linux: python3 -m  http.server -p 8001	(requires python 3)